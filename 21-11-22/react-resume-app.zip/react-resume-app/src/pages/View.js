import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';


function View() {
    const [userDetail, setUserDetail] = useState();
    const parms = useParams();

    const soloUser = async () => {
        const { data } = await axios.get(`https://karka.academy/api/action.php?request=get_react_resume_by_id&user=krish-6&id=${parms.id}`);
        let userData = data.data
        let fullDetail=JSON.parse(userData.data)
        setUserDetail({ ...fullDetail });

    }
    useEffect(() => {
        soloUser()
    }, [ ])

    return (
        <div className='bg-gray'>
            {userDetail &&
                <div className="container mt-5">
                    <h1 className="font-weight-bold text-center">Resume</h1>
                    <h2 id="name" className="font-weight-bold">{userDetail.name}</h2>
                    <p className="font-weight-bold pt-2">E-mail ID :<span className="ps-2" id="email">{userDetail.email}</span></p>
                    <p className="font-weight-bold">Mobile :<span className="ps-2" id="mobile">{userDetail.mobile}</span></p>
                    <p className="font-weight-bold">Role :<span className="ps-2" id="rolename">{userDetail.role}</span></p>

                    <h4>Education:</h4>
                    <div className="container">
                        <table className="table table-bordered  border-dark mt-3">
                            <thead className="text-center">          
                                <tr>
                                    <th scope="col">Course</th>
                                    <th scope="col">Institute</th>
                                    <th scope="col">Year</th>
                                    <th scope="col">Percentage</th>
                                </tr>
                            </thead>
                            <tbody className="text-center" id="education">{userDetail.Education?.map((value, index) => {
                                return (
                                    <tr key={index}>
                                        <td id="course">{value.course}</td>
                                        <td id="instutite">{value.institute}</td>
                                        <td id="year">{value.year}</td>
                                        <td id="percentage">{value.percentage}</td>
                                    </tr>)
                            })}</tbody>
                        </table>
                    </div>
                    <h4>Projects:</h4>
                    <div className="container">
                        <table className="table table-bordered  border-dark mt-3">
                            <thead className="text-center">          
                                <tr>
                                    <th scope="col">Title</th>
                                    <th scope="col">Software Used</th>
                                    <th scope="col">Abstract of the project</th>
                                    
                                </tr>
                            </thead>
                            <tbody className="text-center" id="education">{userDetail.projects?.map((value, index) => {
                                return (
                                    <tr key={index}>
                                        <td id="instutite">{value.title}</td>
                                        <td id="year">{value.software_used}</td>
                                        <td id="course">{value.abstract}</td>                                       
                                        
                                    </tr>)
                            })}</tbody>
                        </table>
                    </div>
                    <hr/>
                    <h5 className="font-weight-bold pt-4">Skills : <span id="skills">{userDetail.skills.join(",")}</span></h5>
                    <hr/>
                    <h5 className="font-weight-bold pt-4 pb-4">Experience:</h5>
                    <div className="container mb-4" id="experience">
                        {userDetail.experience.map((item, value) => {
                            return (
                                <>
                                    <h5 className="font-weight-bold">Organisation : <span className="pl-1" id="organisation">{item.company_name}</span></h5>
                                    <h5 className="font-weight-bold">Role : <span  className="pl-1">{item.role}</span></h5>
                                    <h5 className="font-weight-bold">Year : <span  className="pl-1">{item.start_date} to {item.end_date}</span></h5>

                                </>
                            )
                        })}
                    </div>
                    <hr/>
                    <h6 className="font-weight-bold">Area of intrest :<span className="ps-2" id="rolename">{userDetail.area_of_intrest}</span></h6>
                    <hr/>
                    <h5 className="font-weight-bold pt-4 pb-4">Personal Details</h5>
                    <div className="container">
                    <div className="row">
                            <p className="font-weight-bold col-2">Age</p>
                            <b className="col-1">:</b>
                            <span className="col-5" id="DOB">{userDetail.age}</span>
                        </div>  
                        <div className="row">
                            <p className="font-weight-bold col-2">DOB</p>
                            <b className="col-1">:</b>
                            <span className="col-5" id="DOB">{userDetail.dob}</span>
                        </div>
                        <div className="row">
                            <p className="font-weight-bold col-2">Address</p>
                            <b className="col-1" >:</b>
                            {/* <span className="col-5">{userDetail.personalDetail.join(",")}</span> */}
                            <span className="col-5" id="address">{userDetail.address}</span>
                        </div>
                        <div className="row">
                            <p className="font-weight-bold col-2">State</p>
                            <b className="col-1" >:</b>
                            <span className="col-5" id="gender">{userDetail.state}</span>
                        </div>
                        <div className="row">
                            <p className="font-weight-bold col-2">Gender</p>
                            <b className="col-1" >:</b>
                            <span className="col-5" id="gender">{userDetail.gender}</span>
                        </div>
                        <div className="row">
                            <p className="font-weight-bold col-2">Marital Status</p>
                            <b className="col-1" >:</b>
                            <span className="col-5">{userDetail.marital_status}</span>
                        </div>  
                        <div className="row">
                            <p className="font-weight-bold col-2">Language</p>
                            <b className="col-1" >:</b>
                            <span className="col-5" id="language">{userDetail.language.join(",")}</span>
                        </div>
                        
                    </div>
                </div>
            }
        </div>
    )
}

export default View;