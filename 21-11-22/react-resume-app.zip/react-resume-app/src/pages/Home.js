import React from "react";
import HeaderMain from "../components/headerMain";
import InputFile from "../components/inputFile";
function Home() {

    return (
        <>
            <HeaderMain />
            <InputFile />
        </>

    )
}

export default Home;