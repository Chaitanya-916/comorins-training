import React, { useContext, useEffect, useState } from "react";
import UserContext from "../userContext"
import axios from 'axios';
import { useNavigate } from "react-router-dom";

export default function Login() {  
    const value = useContext(UserContext);
    
    console.log(value);
    let navigate = useNavigate();

    let { isLogged, setLogged} = value;

    const [reqData,setReqData]=useState({
        request: 'candidate_login',
        email: 'vijay@gmail.com',
        password: 'pass@123'
    })

    const checkUser = async () => {
        const {data} = await axios.post('https://karka.academy/api/action.php?', JSON.stringify(reqData));  
        if (data.status == 'success') {         
            setLogged(true);
            navigate('/home')
            localStorage.setItem("login",true);
        }
    }   
    useEffect(
        () => {
            if (isLogged) navigate('/home') 
        }, [isLogged]
    )
    return (
        <div>
            <div className="container-fluid">
                <div className="row no-gutter mt-5 d-flex justify-content-center">
                    <div className="col-md-6 bg-light">
                        <div className="login d-flex align-items-center py-5">

                            <div className="container">
                                <div className="row">
                                    <div className="col-lg-10 col-xl-7 mx-auto">
                                        <h3 className="display-4">Login</h3>
                                        
                                        <p className="text-muted mb-4">Login to create your resume format</p>
                                        <form>
                                            <div className="mb-3">
                                                <input id="inputEmail" type="email" placeholder="Email address"  value={reqData.email} onChange={(e) => setReqData({ ...reqData, email: e.target.value })} autofocus="" className="form-control rounded-pill border-0 shadow-sm px-4" />
                                            </div>
                                            <div className="mb-3">
                                                <input id="inputPassword" type="password" placeholder="Password"  value={reqData.password} onChange={(e) => setReqData({ ...reqData, password: e.target.value })} className="form-control rounded-pill border-0 shadow-sm px-4 text-primary" />
                                            </div>
                                            <div className="d-grid gap-2 mt-2">
                                                <button type="button"  onClick={() => checkUser()} className="btn btn-primary btn-block text-uppercase mb-2 rounded-pill shadow-sm">Sign in</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
