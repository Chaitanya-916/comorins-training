import React, { useContext, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import {
    BrowserRouter as Router,
    Routes,
    Route
} from 'react-router-dom';
import UserContext from './userContext';
import Login from './pages/Login';
import Home from './pages/Home.js';
import View from './pages/View';
import InputFile from './components/inputFile';
function MainRoutes(){

    const [isLogged, setLogged]=useState(false);

    return(
        <UserContext.Provider value= {{isLogged, setLogged}}>
        
            <Router>
                <Routes>
                    <Route path='/' exact element={<Login/>} />
                    <Route path='/home' exact element={<Home />} />
                    <Route path='/view/:id' exact element={<View />} />
                    <Route path='/inputfile' exact element={<InputFile/>} />
                    
                </Routes>
            </Router>
        
        </UserContext.Provider>
    )
}
export default MainRoutes;