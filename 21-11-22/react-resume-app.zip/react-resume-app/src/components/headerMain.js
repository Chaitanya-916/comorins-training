import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom'
import UserContext from '../userContext';
const HeaderMain=()=> {
    const value = useContext(UserContext);
    let { isLogged, setLogged} = value;
    let navigate =useNavigate()
    return (
        <div className='header'>
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav">
                        <li className="nav-item mx-4">
                            <Link to='/home' className='text-white text-decoration-none'>Home</Link>
                        </li>                      
                    </ul>
                </div>
                <div className='d-flex justify-content-end mx-3'>
                    <button className='btn btn-warning' onClick={()=>{setLogged(false);navigate('/')}}> Logout</button>
                </div>                   
            </nav>
        </div>
    )
}
export default HeaderMain;