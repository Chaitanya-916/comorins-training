import React, { useContext, useEffect, useState } from "react";
import axios from 'axios';
import { json, Link, useNavigate } from "react-router-dom";
import UserContext from '../userContext'

export default function InputFile() {

    const value = useContext(UserContext);
    let { isLogged, setLogged } = value;

    const [skill, setSkill] = useState()
    const [education, setEducation] = useState({})
    const [exp, setExp] = useState({})
    const [projectData, setProject] = useState({})
    const [personalData, setPersonalData] = useState({})
    const [languages, setLanguages] = useState()

    const [getData, setGetData] = useState(null)
    const navigate = useNavigate()

    const [myResume, setMyResume] = useState({
        name: '',
        role: '',
        email: null,
        age: null,
        dob: null,
        mobile: null,
        gender: null,
        address: null,
        state: null,
        country: null,
        pin_code: null,
        marital_status: null,
        area_of_intrest: null,
        summary: '',
        skills: [],
        language: [],
        Education: [],
        experience: [],
        projects: [],
        personalDetail: [],
    })

    let localLogin = localStorage.getItem('login');

    let requestData = {
        request: 'create_react_resume',
        user: "krish-6",
        resume: myResume
    }
    const addResume = async () => {

        const dataRes = await axios.post('https://karka.academy/api/action.php?', JSON.stringify(requestData));
        // displayUserData()    
    }

    useEffect(
        () => {
            displayUserData()
        }, [addResume]
    )

    useEffect(
        () => {
            if (!localLogin && !isLogged) { 
                navigate('/')
            }
        }, [isLogged]
    )
    // let showResume;
    const displayUserData = async () => {
        const { data } = await axios.get('https://karka.academy/api/action.php?request=get_user_react_resume&user=krish-6');
        let receivedData = data.data;
        setGetData(receivedData);
    }
    const addDetail = async (key, value) => {
        let update = { ...myResume, [key]: value }
        setMyResume(update);
        //console.log(myResume);
    }
    const addSkill = (key) => {
        let tempArr = { ...myResume, [key]: [...myResume[key], skill] }
        setMyResume(tempArr);
        setSkill('');
    }
    const addLang = (key) => {
        let tempLanguage = { ...myResume, [key]: [...myResume[key], languages] }
        setMyResume(tempLanguage);
    }
    const deleteSkill = (key, index) => {
        let del_list = myResume[key].filter((value, i) => (i != index));
        setMyResume({ ...myResume, [key]: del_list });
    }
    const eduDetail = (key, value) => {
        setEducation({ ...education, [key]: value })
    }
    const eduAdd = () => {
        let tempEdu = [...myResume.Education, education]
        setMyResume({ ...myResume, Education: tempEdu });
        setEducation('')
    }
    const addExp = (key, value) => {
        setExp({ ...exp, [key]: value })
    }
    const expAdd = () => {
        let tempExp = [...myResume.experience, exp]
        setMyResume({ ...myResume, experience: tempExp });
    }
    const addProject = (key, value) => {
        setProject({ ...projectData, [key]: value })
    }
    const projectAdd = () => {
        let tempProj = [...myResume.projects, projectData]
        setMyResume({ ...myResume, projects: tempProj });
    }
    const personalDetails = (key, value) => {
        setPersonalData({ ...personalData, [key]: value })
    }
    const addPesonalDetails = () => {
        let tempPersonal = [...myResume.personalDetail, personalData]
        setMyResume({ ...myResume, personalDetail: tempPersonal })
    }
    const deleteUserId = async (userID) => {
        const deleteData = await axios.get(`https://karka.academy/api/action.php?request=delete_react_user_resume&user=krish-6&id=${userID}`);
        console.log("deldata", deleteData.data.data);
        setGetData(deleteData.data.data);
    }
    return (
        <div className="mainbody">
            <div className="container" >
                <div classNameName=" row form-group">
                    <label>Name: </label>
                    <input className="form-control w-25" type="text" onKeyUp={(e) => addDetail('name', e.target.value)} />
                    <label>Role: </label>
                    <input className="form-control w-25" type="text" onKeyUp={(e) => addDetail('role', e.target.value)} />
                    <label>Email:</label>
                    <input className="form-control w-25" type="email" onKeyUp={(e) => addDetail('email', e.target.value)} />
                    <small className="form-text text-white ">We'll never share your email with anyone else.</small><br />
                    <label>Mobile-no:</label>
                    <input className="form-control w-25" type="number" onKeyUp={(e) => addDetail('mobile', e.target.value)} /><br />
                    <label>Summary:</label>
                    <textarea className="form-control w-25" type="text" onKeyUp={(e) => addDetail('summary', e.target.value)}></textarea><br />
                    <label>Experiance:</label><br />
                    <label>Role:</label>
                    <input className="form-control w-25" type="text" onKeyUp={(e) => addExp('role', e.target.value)} />
                    <label>Company Name:</label>
                    <input className="form-control w-25" type="text" onKeyUp={(e) => addExp('company_name', e.target.value)} />
                    <label>place:</label>
                    <input className="form-control w-25" type="text" onKeyUp={(e) => addExp('place', e.target.value)} />
                    <label>Date of start:</label>
                    <input type="date" onKeyUp={(e) => addExp('start_date', e.target.value)} />
                    <label>Date of releave:</label>
                    <input type="date" onKeyUp={(e) => addExp('end_date', e.target.value)} /><br />
                    <button onClick={expAdd}>+</button>
                    <br />
                    <label>Area of intrest</label>
                    <input className="form-control w-25" type="text" onKeyUp={(e) => addDetail('area_of_intrest', e.target.value)} /><br />
                    <label>Skills:</label>
                    <input className="form-control w-25" type="text" onKeyUp={(e) => setSkill(e.target.value)} /> <label>  </label>
                    <button type='submit' onClick={(e) => addSkill('skills', skill)}>+</button>
                    <br />
                    {myResume.skills && myResume.skills.map((val, index) => {
                        return (
                            <div className="container-fluid" key={index}>
                                <table border={1}>
                                    <p> {val}  <button type="submit" onClick={() => deleteSkill('skills', index)}>-</button></p>
                                </table>
                            </div>
                        )
                    })}<br />
                    <h4>Education:</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Cource</th>
                                <th>year</th>
                                <th>Institute</th>
                                <th>Percentage</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><input className="form-control" type="text" onKeyUp={(e) => eduDetail('course', e.target.value)} /></td>
                                <td><input className="form-control" type="text" onKeyUp={(e) => eduDetail('year', e.target.value)} /></td>
                                <td><input className="form-control" type="text" onKeyUp={(e) => eduDetail('institute', e.target.value)} /></td>
                                <td><input className="form-control" type="text" onKeyUp={(e) => eduDetail('percentage', e.target.value)} /></td>
                                <button type="submit" onClick={() => eduAdd()}>+</button>
                            </tr>
                        </tbody>
                    </table>
                    <br />
                    <h4>Projects:</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Abstract</th>
                                <th>Software Used</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><input className="form-control" type="text" onKeyUp={(e) => addProject('title', e.target.value,)} /></td>
                                <td><textarea className="form-control" type="text" onKeyUp={(e) => addProject('abstract', e.target.value,)}></textarea></td>
                                <td><input className="form-control" type="text" onKeyUp={(e) => addProject('software_used', e.target.value,)} />
                                    <button className="bg-dark text-white" type="submit" onClick={projectAdd}>Add</button></td>
                            </tr>
                        </tbody>
                    </table>
                    <br />
                    <h4>Personal Details: </h4><br />
                    <label>Age:</label>
                    <input className="form-control w-25" type="text" onKeyUp={(e) => addDetail('age', e.target.value)} /><br />
                    <label>DOB:</label>
                    <input className="form-control w-25" type="text" onKeyUp={(e) => addDetail('dob', e.target.value)} /><br />
                    <label>Gender:</label>
                    <input className="form-control w-25" type="text" onKeyUp={(e) => addDetail('gender', e.target.value)} /><br />
                    <label>marital status:</label>
                    <input className="form-control w-25" type="text" onKeyUp={(e) => addDetail('marital_status', e.target.value)} /><br />
                    <br />
                    {/* <h5>Address:</h5> */}
                    <form>
                        <div class="form-group">
                            <label for="inputAddress">Address</label>
                            <input type="text" class="form-control w-25" onKeyUp={(e) => addDetail('address', e.target.value)} placeholder="1234 Main St" />
                        </div>
                    </form>
                    <div className=" pb-2 col-3">
                        <label>State:</label>
                        <input className="form-control" type="text" onKeyUp={(e) => addDetail('state', e.target.value)} /><br />
                        <label>country:</label>
                        <input className="form-control" type="text" onKeyUp={(e) => addDetail('country', e.target.value)} /><br />
                        <label>Pin-Code:</label>
                        <input className="form-control" type="number" onKeyUp={(e) => addDetail('pin_code', e.target.value)} /><br />
                    </div>

                    <label>Languages Known:</label>
                    <br />
                    <input className="form-control w-25" type="text" onKeyUp={(e) => setLanguages(e.target.value)} />
                    <button type='submit' onClick={(e) => addLang('language', skill)}>+</button>
                    {myResume.language && myResume.language.map((val, index) => {
                        return (
                            <div className="container-fluid" key={index}>
                                <table border={1}>
                                    <p> {val}  <button className="form-control" type="submit" onClick={() => deleteSkill('language', index)}>-</button></p>
                                </table>
                            </div>
                        )
                    })}
                    <br />
                    <button onClick={addResume}>Submit</button>
                    <div>
                        <code id="objective"></code>
                    </div>
                    <hr/>
                    <br/>
                    <h4 >Users:</h4>
                    {getData && getData.map((val, index) => {
                        var arrGetData = JSON.parse(val.data)

                        return (<>
                            <table className="table">
                                <tbody>
                                    <tr >
                                        <td className="text-warning">
                                            {index + 1}
                                        </td>
                                        <td className="col-8 text-white"> {arrGetData.name}</td>
                                        <td><button type="submit" onClick={() => deleteUserId(val.id)}>del</button></td>
                                        <td> <Link to={`/view/${val.id}`} className="btn btn-primary ">view</Link></td>
                                    </tr>
                                </tbody>
                            </table>
                        </>)
                    })}

                </div>
            </div>
        </div>
    )
}
